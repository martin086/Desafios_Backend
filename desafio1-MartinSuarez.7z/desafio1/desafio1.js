/*Desafio 1*/
class ProductManager {
    static idCounter = 0;
    constructor(title, description, price, thumbnail, code, stock) {
        this.title = title
        this.description = description
        this.price = price
        this.thumbnail = thumbnail
        this.stock = stock
        this.code = code
        this.id = ++ProductManager.idCounter
        this.products = []
    }

    addProduct () {
        const title = prompt("Nombre del producto: ");
        const description = prompt("Descripción del producto: ");
        const precio = parseInt(prompt("Precio: "));
        const thumbnail = prompt("Ruta de imagen: ");
        const code = prompt(parseInt("Código identificador: "));
        const stock = prompt(parseInt("Stock disponible: "));

        const nuevoProducto = new ProductManager(title, description, precio, thumbnail, code, stock);

        if (products.find(nuevoProducto => nuevoProducto.code === code)) {
            this.code = prompt(parseInt("Ingrese un código identificador distinto: "));
            
        } else {
            products.push(nuevoProducto);
            console.log(nuevoProducto);
        }
    }

    getProducts() {
        console.log(this.products);
    }

    getProductById(id) {
        if (producto = products.find(producto => producto.id === id)) {
            let index = products.indexOf(producto);
            console.log(products[index]);
        } else {
            console.log("Not found");
        }
    }

}

addProduct();
getProducts();
getProductById(1);

